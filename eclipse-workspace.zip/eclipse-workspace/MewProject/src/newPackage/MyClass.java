package newPackage;

import org.openqa.selenium.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.ArrayList;
import java.util.List;
//comment the above line and uncomment below line to use Chrome
//import org.openqa.selenium.chrome.ChromeDriver;
public class MyClass {


    public static void main(String[] args) throws InterruptedException {
        // declaration and instantiation of objects/variables
    	System.setProperty("webdriver.gecko.driver","C:\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		//comment the above 2 lines and uncomment below 2 lines to use Chrome
		//System.setProperty("webdriver.chrome.driver","G:\\chromedriver.exe");
		//WebDriver driver = new ChromeDriver();
    	
    
        String baseUrl = "https://www.mercadolibre.com";
        driver.get(baseUrl);        
        //WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        
        WebElement mxLink = driver.findElement(By.xpath("/html[1]/body[1]/nav[1]/ul[1]/li[11]/a[1]"));
        Thread.sleep(3000); mxLink.click();
        WebElement acceptCookies = driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div[2]/button[1]"));
        Thread.sleep(3000); acceptCookies.click();
        WebElement searchBox = driver.findElement(By.xpath("//*[@id=\"cb1-edit\"]"));
        Thread.sleep(3000); searchBox.sendKeys("playstation 5"); 
        WebElement searchButton = driver.findElement(By.xpath("/html[1]/body[1]/header[1]/div[1]/div[2]/form[1]/button[1]"));
        Thread.sleep(3000); searchButton.click(); 
        WebElement filterNuevos = driver.findElement(By.xpath("/html[1]/body[1]/main[1]/div[1]/div[3]/aside[1]/section[2]/div[6]/ul[1]/li[1]/a[1]/span[1]"));
        Thread.sleep(3000); filterNuevos.click();
        WebElement filterCDMX = driver.findElement(By.xpath("/html[1]/body[1]/main[1]/div[1]/div[3]/aside[1]/section[2]/div[13]/ul[1]/li[1]/a[1]/span[1]"));
        Thread.sleep(3000); filterCDMX.click();
        WebElement expandDropdown = driver.findElement(By.xpath("/html[1]/body[1]/main[1]/div[1]/div[3]/section[1]/div[2]/div[2]/div[1]/div[1]/div[2]/div[1]"));
        Thread.sleep(3000); expandDropdown.click(); 
        WebElement optionMayor = driver.findElement(By.xpath("/html[1]/body[1]/main[1]/div[1]/div[3]/section[1]/div[2]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[3]/div[1]"));
        Thread.sleep(3000); optionMayor.click(); 
        List <WebElement> firstFiveProducts = driver.findElements(By.xpath("(//h2//a)[position() <= 5]"));
        List <String> firstFiveProdNames = new ArrayList<>();
        for (WebElement link: firstFiveProducts) {
        	firstFiveProdNames.add(link.getText());
        }
        System.out.println(firstFiveProdNames);
        Thread.sleep(10000);
        
    
        // launch Fire fox and direct it to the Base URL
        

        // get the actual value of the title
        

        /*
         * compare the actual title of the page with the expected one and print
         * the result as "Passed" or "Failed"
         */
       
        //close Fire fox
        driver.close();
    }

}