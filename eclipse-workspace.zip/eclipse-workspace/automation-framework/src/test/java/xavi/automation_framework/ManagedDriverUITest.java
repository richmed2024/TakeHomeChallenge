package xavi.automation_framework;

public abstract class ManagedDriverUITest extends UITest {
 
    @BeforeEach
    public void createDefaultDriver() {
        newDriver();
    }
 
    @AfterEach
    public void closeDriver() {
        // Takes care of the driver when the test finishes
        if (driver != null) {
                driver.close();
        }
    }
}