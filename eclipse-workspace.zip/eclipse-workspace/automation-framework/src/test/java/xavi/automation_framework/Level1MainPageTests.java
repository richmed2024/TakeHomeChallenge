package xavi.automation_framework;

@Execution(ExecutionMode.CONCURRENT)
class Level1MainPageTests extends UITest {
   
	class Level1MainPageTests extends AutomationPracticeTest {
		 
	    @Test
	    @DisplayName("Check the start button works")
	    void testStartButtonWorks() {
	        Level1MainPage page = new Level1MainPage(driver);
	        page.clickStartButton();
	        Assertions.assertTrue(driver.getCurrentUrl().endsWith("level2"));
	    }
	}
}
