package xavi.automation_framework;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

@Execution(ExecutionMode.CONCURRENT)
class MainTest extends UITest {
   
    @Test
    @DisplayName("Check the start button works")
    void testStartButtonWorks() {
        newDriver("https://automation-practice.web.app");
        Level1MainPage page = new Level1MainPage(driver);
        page.clickStartButton();
      Assertions.assertTrue(driver.getCurrentUrl().endsWith("level2"));
        driver.close();
    }
}