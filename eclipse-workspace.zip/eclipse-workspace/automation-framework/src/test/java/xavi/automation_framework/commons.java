package xavi.automation_framework;

public class commons {

}
