package xavi.automation_framework;

public class Main{
	 
    public static void main (String [ ] args) {
         System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
         Driver driver = DriverFactory.chromeDriver();         
         driver.get("https://automation-practice.web.app");
         
         Level1MainPage page = new Level1MainPage(driver);
         page.clickStartButton();
         /* Añadimos la siguiente linea para que nos de tiempo a comprobar 
     visualmente que realmente ha hecho click y ha cambiado de nivel. */
         Thread.sleep(10000); 
          
         driver.close();
    } 
} 
