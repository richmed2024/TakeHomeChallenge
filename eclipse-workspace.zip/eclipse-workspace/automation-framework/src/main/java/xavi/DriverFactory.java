package Driver;

public class DriverFactory {
 
    private DriverFactory() {}
 
    public static Driver getDriver(Browser browser) {
        switch(browser) {
            case CHROME:
                return chromeDriver();
            default:
                return firefoxDriver();
        }
    }
 
    public static Driver chromeDriver() {
        ChromeDriver driver = new ChromeDriver(getChromeOptions());
        driver.manage().window().maximize();
        return new DriverForChrome(driver);
    }
 
    public static Driver firefoxDriver() {
        FirefoxDriver driver = new FirefoxDriver(getFirefoxOptions());
        driver.manage().window().maximize();
        return new DriverForFirefox(driver);
    }
 
    private static ChromeOptions getChromeOptions() {
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.setAcceptInsecureCerts(true);
        chromeOptions.addArguments("--incognito");
        return chromeOptions;
    }
 
    private static FirefoxOptions getFirefoxOptions() {
        FirefoxOptions firefoxOptions = new FirefoxOptions();
        firefoxOptions.setAcceptInsecureCerts(true);
     firefoxOptions.addPreference("browser.private.browsing.autostart", true);
        return firefoxOptions;
    }
    public static Driver defaultDriver() {
        if ("CHROME".equals(System.getProperty("default.browser"))) {
            return chromeDriver();
        }
        return firefoxDriver();
    }
}
