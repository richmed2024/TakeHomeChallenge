package Driver;

public abstract class Driver {
	 
    private static final Logger LOGGER = Logger.getLogger("MainLogger");
 
    protected final WebDriver webDriver;
 
    protected Driver(WebDriver webDriver) {
        this.webDriver = webDriver;
    }
 
    public WebDriver getWebDriver() {
        return webDriver;
    }
 
    public void close() {
        try {
            webDriver.close(); // Close current execution window
        } catch(Exception e) {
            LOGGER.info(e.getMessage());
        } finally {
            webDriver.quit();  // Safely close drive session
        }
    }
 
    public void get(String url) {
        webDriver.get(url);
    }
 
    public String getCurrentUrl() {
        return webDriver.getCurrentUrl();
    }
    public WebElement findElement(String selector) {
        return findElement(By.cssSelector(selector));
    }
     
    private WebElement findElement(By by) {
        return webDriver.findElement(by);
    }
     
    public List<WebElement> findElements(String selector) {
        return findElements(By.cssSelector(selector));
    }
     
    public List<WebElement> findElements(By by) {
        return webDriver.findElements(by);
    }
    
    public void click(String selector) {
        click(By.cssSelector(selector));
    }
     
    public void click(By by) {
        click(findElement(by));
    }
     
    public void click(WebElement element) {
        element.click();
    }
    public String screenShot() {
        return screenShot("");
    }
     
    public String screenShot(String prefix) {
        String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS"));
        String screenShotPath = System.getProperty("screenshot.folder") + "\\" + (!prefix.isEmpty() ? prefix + "_" : "") + date + ".png";
     
        try {
            File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screenshot, new File(screenShotPath));
            return screenShotPath;
        } catch (IOException e) {
            LOGGER.severe("[IMG] Could not take screenshot. " + e.getMessage());
        }
        return null;
    }
     
    public String saveHtml(String prefix) {
        String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS"));
        String htmlPath = System.getProperty("html.folder") + "\\" + (!prefix.isEmpty() ? prefix + "_" : "") + date + ".html";
        File sourceFile = new File(htmlPath);
        try (FileWriter writer = new FileWriter(sourceFile)){
            writer.write(webDriver.getPageSource());
            return htmlPath;
        } catch (IOException e) {
            LOGGER.severe("[HTML] Could not save page source. " + e.getMessage());
        }
        return null;
    }
}