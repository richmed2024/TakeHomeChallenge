package Driver;

public class DriverForFirefox extends Driver {
    public DriverForFirefox(FirefoxDriver driver) {
        super(driver);
    }
}