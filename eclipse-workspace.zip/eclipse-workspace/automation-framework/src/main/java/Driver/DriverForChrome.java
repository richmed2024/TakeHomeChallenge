package Driver;

public class DriverForChrome extends Driver {
    public DriverForChrome(ChromeDriver driver) {
        super(driver);
    }
}