package package_pages;

public abstract class WebPage {
	 
    protected static final Logger LOGGER = Logger.getLogger("MainLogger");
 
    protected final Driver driver;
 
    public WebPage(Driver driver) {
        this.driver = driver;
    }
}