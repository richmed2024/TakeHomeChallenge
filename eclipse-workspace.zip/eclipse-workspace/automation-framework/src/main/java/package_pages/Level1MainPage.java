package package_pages;

public class Level1MainPage extends WebPage {
	 
    public Level1MainPage(Driver driver) {
        super(driver);
    }
 
    public void clickStartButton() {
        driver.click("#start_button");
    }
}}
